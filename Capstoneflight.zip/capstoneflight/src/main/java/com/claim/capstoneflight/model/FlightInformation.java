package com.claim.capstoneflight.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.claim.capstoneflight.controller.AppController;
import com.claim.capstoneflight.utils.LocalDateAttributeConverter;
import com.claim.capstoneflight.utils.LocalDateTimeAttributeConverter;

@Entity
@Table(name = "flight_information")
public class FlightInformation {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private long id;

	@Column
	@Convert(converter = LocalDateAttributeConverter.class)
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private LocalDate date;
	private String destination;
	private int gate;

	private String origin;

//	@Column
//	@DateTimeFormat(pattern="HH:MM")
//	@Convert(converter = LocalDateTimeAttributeConverter.class)
//	private LocalDateTime departureTime;
	
	private String departureTime;
	private String arrivalTime;
	private String flightNumber;

//	@Column
//	@DateTimeFormat(pattern="HH:MM")
//	@Convert(converter = LocalDateTimeAttributeConverter.class)
//	private LocalDateTime arrivalTime;
	private int totalFlights;

	public void FlightInformation(String destination, int gate, String date, String departureTime) {

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

		date += "/2020";

		this.date = LocalDate.parse(date, formatter);

		this.destination = destination;

		this.gate = gate;

		departureTime = date + " " + departureTime;

		formatter = DateTimeFormatter.ofPattern("dd/MM/yyy HH:mm");

		this.departureTime = departureTime;
		

		caclulateArrivalTime();

	}

	public String getFlightNumber() {

		return this.flightNumber;

	}

	public void setFlightNumber(String flightNumber) {

		this.flightNumber = flightNumber;

	}

	public String getDestination() {

		return destination;

	}

	public void setDestination(String destination) {

		this.destination = destination;

	}

	public int getGate() {

		return gate;

	}

	public void setGate(int gate) {

		this.gate = gate;

	}

	public LocalDate getDate() {

		return date;

	}

	public void setDate(LocalDate date) {

		this.date = date;

	}

	public String getDepartureTime() {

		return departureTime;

	}

	public void setDepartureTime(String departureTime) {

		this.departureTime = departureTime;

		this.caclulateArrivalTime();

	}

	public String getArrivalTime() {

		return this.arrivalTime;

	}

	public void setArrivalTime(String arrivalTime) {

		this.arrivalTime = arrivalTime;

	}

	public int getTotalFlights() {

		return this.totalFlights;

	}

	public void setTotalFlights(int totalFlights) {

		this.totalFlights = totalFlights;

	}

	private void generateFlightNumber() {

		flightNumber = destination.substring(0, 3).toLowerCase() + "00" + (totalFlights);

	}

	private void caclulateArrivalTime() {

		// arrivalTime=departureTime.plusMinutes(map.get(destination.toLowerCase()));

	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

}
