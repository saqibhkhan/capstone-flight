package com.claim.capstoneflight;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapstoneFlight {

	public static void main(String[] args) {
		SpringApplication.run(CapstoneFlight.class, args);
	}

}
