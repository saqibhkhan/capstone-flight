package com.claim.capstoneflight.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.claim.capstoneflight.model.FlightInformation;
import com.claim.capstoneflight.repository.FlightInformationRepository;

@Controller
public class AppController {

	@Autowired
	private FlightInformationRepository flightInformationRepository;
	
	@GetMapping({"index", "/"})
	public String home(Model model) {
		model.addAttribute("addedflight", new FlightInformation());
		return "index";
	}
	
	
	@PostMapping("newflight")
	public String newflight(@ModelAttribute FlightInformation addedflight, Model model) {
		model.addAttribute("flightInformation", addedflight);
		flightInformationRepository.save(addedflight);
		model.addAttribute("addedflight", new FlightInformation());
		
		return "index";
	}

	
@GetMapping("flightinfo")
public String editRole(RedirectAttributes model,@RequestParam long id) {
	FlightInformation flight = flightInformationRepository.findById(id).get();
	model.addAttribute("flight", flight);
	return "details";
}

}



