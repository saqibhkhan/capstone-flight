package com.claim.capstoneflight.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.claim.capstoneflight.model.FlightInformation;


@Repository
public interface FlightInformationRepository extends JpaRepository<FlightInformation, Long>{
	
	@Query("FROM FlightInformation WHERE Airline=?1")
	List<FlightInformationRepository> findByAirline(String airline);
	
	@Query("FROM FlightInformation WHERE Number=?1")
	List<FlightInformationRepository> findByNumber(String number);
	
	@Query("FROM FlightInformation WHERE Departure=?1")
	Optional<FlightInformationRepository> findDeparture(String departure);
	
	@Query("FROM FlightInformation WHERE Arrival=?1")
	Optional<FlightInformationRepository> findArrival(String arrival);
	
	@Query("FROM FlightInformation WHERE DepartureTime=?1")
	Optional<FlightInformationRepository> findDepartureTime(String departureTime);
	
	@Query("FROM FlightInformation WHERE ArrivalTime=?1")
	Optional<FlightInformationRepository> findArrivalTime(String arrivalTime);
	
}
